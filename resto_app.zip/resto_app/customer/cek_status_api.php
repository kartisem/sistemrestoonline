<?php
include '../config/koneksi.php';

header('Content-Type: application/json');
header('Cache-Control: no-store, no-cache, must-revalidate');

if(!isset($_GET['order'])){
    echo json_encode(['error' => 'No pesanan tidak ada']);
    exit;
}

$order = mysqli_real_escape_string($conn, $_GET['order']);

$res = mysqli_query($conn,
    "SELECT status_pembayaran, status_pesanan, waktu_diantar, waktu_selesai
     FROM transaksi
     WHERE no_pesanan = '$order'
     LIMIT 1"
);

if(!$res || mysqli_num_rows($res) === 0){
    echo json_encode(['error' => 'Pesanan tidak ditemukan']);
    exit;
}

$row = mysqli_fetch_assoc($res);

$sisa_waktu = null;

if($row['status_pesanan'] == 'diantar'){
    // Jika waktu_diantar kosong atau tidak valid, set ulang ke NOW()
    if(empty($row['waktu_diantar']) || strtotime($row['waktu_diantar']) > time() + 300){
        mysqli_query($conn, "UPDATE transaksi SET waktu_diantar = NOW() WHERE no_pesanan='$order'");
        $row['waktu_diantar'] = date('Y-m-d H:i:s');
    }

    $waktu_diantar = strtotime($row['waktu_diantar']);
    $waktu_3menit  = $waktu_diantar + 180;
    $sisa_detik    = $waktu_3menit - time();

    if($sisa_detik <= 0){
        // Waktu habis → otomatis selesai
        mysqli_query($conn,
            "UPDATE transaksi SET status_pesanan='selesai', waktu_selesai=NOW()
             WHERE no_pesanan='$order'"
        );
        $row['status_pesanan'] = 'selesai';
        $sisa_waktu = null;
    } else {
        $sisa_waktu = $sisa_detik;
    }
}

echo json_encode([
    'status_pembayaran' => $row['status_pembayaran'],
    'status_pesanan'    => $row['status_pesanan'],
    'sisa_waktu'        => $sisa_waktu,
]);
exit;
?>