<?php
session_start();
include '../config/koneksi.php';

if(!isset($_GET['order'])){
    die("No pesanan tidak ditemukan");
}

$order = htmlspecialchars($_GET['order']);
$meja = isset($_GET['meja']) ? $_GET['meja'] : '';

// Ambil data transaksi dari database
$res = mysqli_query($conn, "SELECT metode_pembayaran FROM transaksi WHERE no_pesanan='$order' LIMIT 1");
$transaksi = mysqli_fetch_array($res);

// Cek metode pembayaran
$metode_pembayaran = isset($transaksi['metode_pembayaran']) ? $transaksi['metode_pembayaran'] : '';

// Jika belum ada di database, cek dari parameter GET
if(empty($metode_pembayaran) && isset($_GET['metode'])){
    $metode_pembayaran = $_GET['metode'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Pesanan Berhasil</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
  :root{ --green:#22c55e; --green2:#16a34a; --accent:#f97316; --blue:#3b82f6; --blue2:#2563eb; }
  body{
    background:linear-gradient(135deg,#f0fdf4 0%,#dcfce7 100%);
    min-height:100vh; font-family:'Plus Jakarta Sans',sans-serif;
    display:flex; align-items:center; justify-content:center; padding:24px;
  }
  .card-wrap{ width:100%; max-width:480px; }
  .card{
    border:none; border-radius:24px; overflow:hidden;
    box-shadow:0 8px 40px rgba(0,0,0,.12);
  }
  .card-top{
    padding:40px 28px 28px; text-align:center; position:relative; overflow:hidden;
  }
  .card-top.qris { background:linear-gradient(135deg,var(--green),var(--green2)); }
  .card-top.tunai { background:linear-gradient(135deg,var(--blue),var(--blue2)); }
  .card-top::before{
    content:''; position:absolute; bottom:-35px; left:-35px;
    width:110px; height:110px; border-radius:50%; background:rgba(255,255,255,.07);
  }
  .check{ font-size:76px; line-height:1; animation:zoom .9s infinite alternate ease-in-out; }
  @keyframes zoom{ from{transform:scale(1);} to{transform:scale(1.08);} }
  .card-top h2{ font-weight:800; font-size:1.35rem; color:#fff; margin-top:14px; margin-bottom:4px; }
  .card-top p { font-size:.875rem; color:rgba(255,255,255,.88); margin:0; }
  .card-body-wrap{ background:#fff; padding:24px 28px; }
  .alert-box{
    border:none; border-radius:13px; padding:15px 18px;
    margin-bottom:18px;
  }
  .alert-box.qris { background:#fef3c7; color:#b45309; }
  .alert-box.tunai { background:#e0f2fe; color:#0369a1; }
  .alert-box h5{ font-weight:700; margin-bottom:3px; font-size:.95rem; }
  .alert-box p { font-size:.82rem; margin:0; opacity:.85; }
  .order-box{
    background:#f8fafc; border:1px solid #e2e8f0;
    border-radius:13px; padding:18px; text-align:center; margin-bottom:22px;
  }
  .order-box .lbl{ font-size:.68rem; font-weight:600; letter-spacing:.08em; text-transform:uppercase; color:#94a3b8; margin-bottom:8px; }
  .order-box .num{ font-size:1.55rem; font-weight:800; color:var(--green2); letter-spacing:.03em; }
  .btn-cek{
    display:block; width:100%;
    background:linear-gradient(135deg,var(--accent),#ea580c);
    color:#fff; border:none; border-radius:13px;
    padding:13px; font-size:.9rem; font-weight:700;
    text-align:center; text-decoration:none;
    transition:transform .2s, box-shadow .2s;
  }
  .btn-cek:hover{ transform:translateY(-2px); box-shadow:0 6px 18px rgba(249,115,22,.3); color:#fff; }
  .info-tunai{
    background:#f1f5f9;
    border-radius:13px;
    padding:15px;
    margin-bottom:18px;
    text-align:center;
  }
  .info-tunai .icon{ font-size:48px; margin-bottom:10px; }
  .info-tunai h6{ font-weight:700; color:#1e293b; margin-bottom:5px; }
  .info-tunai p{ font-size:.8rem; color:#64748b; margin:0; }
</style>
</head>
<body>
<div class="card-wrap">
  <div class="card">
    <div class="card-top <?= $metode_pembayaran == 'Tunai' ? 'tunai' : 'qris' ?>">
      <div class="check"><?= $metode_pembayaran == 'Tunai' ? '💰' : '✅' ?></div>
      <h2>
        <?php if($metode_pembayaran == 'Tunai'): ?>
          Pesanan Berhasil!
        <?php else: ?>
          Pesanan Berhasil Dikirim!
        <?php endif; ?>
      </h2>
      <p>
        <?php if($metode_pembayaran == 'Tunai'): ?>
          Silahkan selesaikan pembayaran di kasir
        <?php else: ?>
          Pesanan Anda sudah masuk ke sistem kami
        <?php endif; ?>
      </p>
    </div>
    <div class="card-body-wrap">

      <?php if($metode_pembayaran == 'Tunai'): ?>
        <!-- Tampilan untuk PEMBAYARAN TUNAI -->
        <div class="info-tunai">
          <div class="icon">🏧</div>
          <h6>Silahkan menuju kasir</h6>
          <p>Untuk melanjutkan pembayaran tunai, harap temui kasir kami.</p>
        </div>
        <div class="alert-box tunai">
          <h5>💰 Pembayaran Tunai</h5>
          <p>Segera selesaikan pembayaran Anda di kasir agar pesanan segera diproses.</p>
        </div>
      <?php else: ?>
        <!-- Tampilan untuk QRIS -->
        <div class="alert-box qris">
          <h5>🍳 Makanan Sedang Dipersiapkan</h5>
          <p>Silahkan menuju ke kasir untuk menyelesaikan pembayaran.</p>
        </div>
      <?php endif; ?>

      <div class="order-box">
        <div class="lbl">Nomor Pesanan Anda</div>
        <div class="num"><?= $order ?></div>
      </div>

      <a href="cek_status.php?order=<?= urlencode($order) ?>&meja=<?= $meja ?>" class="btn-cek">
        🔎 Pantau Status Pesanan
      </a>
    </div>
  </div>
</div>
</body>
</html>