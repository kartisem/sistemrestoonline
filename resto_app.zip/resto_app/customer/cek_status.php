<?php
include '../config/koneksi.php';

if(!isset($_GET['order'])){
    die("No pesanan tidak ditemukan");
}

$order = mysqli_real_escape_string($conn, $_GET['order']);

$res = mysqli_query($conn,
    "SELECT * FROM transaksi WHERE no_pesanan='$order' LIMIT 1"
);

$d = mysqli_fetch_array($res);

if(!$d){
    die("Data pesanan tidak ditemukan");
}

// Hitung sisa waktu untuk status diantar
$sisa = 180;
if($d['status_pesanan'] === 'diantar' && !empty($d['waktu_diantar'])){
    $waktu_diantar = strtotime($d['waktu_diantar']);
    $sisa = ($waktu_diantar + 180) - time();
    if($sisa > 180) $sisa = 180;
    if($sisa < 0) $sisa = 0;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Status Pesanan — <?= htmlspecialchars($order) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
  :root{ --accent:#f97316; --accent2:#ea580c; }

  body{
    background:linear-gradient(135deg,#fff7f0 0%,#ffe4d6 100%);
    min-height:100vh; font-family:'Plus Jakarta Sans',sans-serif;
    display:flex; align-items:center; justify-content:center; padding:24px;
  }

  .card-wrap{ width:100%; max-width:520px; }

  .status-card{
    border:none; border-radius:24px; overflow:hidden;
    box-shadow:0 8px 40px rgba(0,0,0,.13);
  }

  .card-top{
    padding:36px 28px 26px; text-align:center;
    transition:background .5s;
  }
  .card-top.menunggu { background:linear-gradient(135deg,#f97316,#ea580c); }
  .card-top.diproses { background:linear-gradient(135deg,#f59e0b,#d97706); }
  .card-top.diantar  { background:linear-gradient(135deg,#8b5cf6,#7c3aed); }
  .card-top.selesai  { background:linear-gradient(135deg,#22c55e,#16a34a); }
  .card-top.gagal    { background:linear-gradient(135deg,#ef4444,#dc2626); }

  .status-icon{ font-size:64px; line-height:1; display:block; }
  .card-top h2{ font-weight:800; font-size:1.3rem; color:#fff; margin-top:14px; margin-bottom:4px; }
  .card-top p { font-size:.875rem; color:rgba(255,255,255,.88); margin:0; }
  .card-body-wrap{ background:#fff; padding:24px 28px; }
  .info-row{
    display:flex; background:#f8fafc;
    border:1px solid #e2e8f0; border-radius:13px;
    overflow:hidden; margin-bottom:18px;
  }
  .info-col{ flex:1; padding:12px 14px; text-align:center; }
  .info-col + .info-col{ border-left:1px solid #e2e8f0; }
  .info-col .lbl{ font-size:.65rem; font-weight:600; text-transform:uppercase; color:#94a3b8; margin-bottom:4px; }
  .info-col .val{ font-weight:700; font-size:.9rem; color:#1e293b; }
  .status-alert{
    border-radius:13px; padding:16px 18px; margin-bottom:14px;
  }
  .alert-pending  { background:#f1f5f9; color:#475569; }
  .alert-lunas    { background:#dcfce7; color:#15803d; }
  .alert-gagal    { background:#fee2e2; color:#b91c1c; }
  .alert-menunggu { background:#e0f2fe; color:#0369a1; }
  .alert-diproses { background:#fef3c7; color:#b45309; }
  .alert-diantar  { background:#ede9fe; color:#6d28d9; }
  .alert-selesai  { background:#dcfce7; color:#15803d; }
  .status-alert h4{ font-weight:700; font-size:1rem; margin-bottom:3px; }
  .status-alert p { font-size:.82rem; margin:0; }
  .timer-box {
    background:linear-gradient(135deg, #1e293b, #0f172a);
    border-radius:13px;
    padding:16px;
    text-align:center;
    margin-bottom:14px;
  }
  .timer-box .label {
    font-size:.7rem;
    text-transform:uppercase;
    letter-spacing:.1em;
    color:#94a3b8;
    margin-bottom:6px;
  }
  .timer-box .time {
    font-size:2rem;
    font-weight:800;
    color:#f97316;
    font-family:monospace;
  }
  .refresh-bar{
    background:#f1f5f9; border-radius:10px; padding:10px 14px;
    font-size:.77rem; color:#64748b; text-align:center;
    margin-top:6px;
  }
</style>
</head>
<body>

<div class="card-wrap">
  <div class="status-card">

    <div class="card-top <?= $d['status_pesanan'] ?>" id="cardTop">
      <span class="status-icon" id="statusIcon">
        <?php
          $icons = ['menunggu'=>'⏳','diproses'=>'🍳','diantar'=>'🛵','selesai'=>'✅','gagal'=>'❌'];
          echo $icons[$d['status_pesanan']] ?? '❓';
        ?>
      </span>
      <h2 id="headerTitle">
        <?php
          $titles = [
            'menunggu' => 'Menunggu Konfirmasi',
            'diproses' => 'Sedang Dimasak',
            'diantar'  => 'Sedang Diantar',
            'selesai'  => 'Pesanan Selesai! 🎉',
            'gagal'    => 'Pesanan Ditolak',
          ];
          echo $titles[$d['status_pesanan']] ?? '';
        ?>
      </h2>
      <p id="headerSub">
        <?php
          $subs = [
            'menunggu' => 'Pesanan sedang menunggu konfirmasi admin',
            'diproses' => 'Harap tunggu sekitar 10 menit ya!',
            'diantar'  => 'Pesanan dalam perjalanan ke meja Anda',
            'selesai'  => 'Terima kasih telah makan di resto kami',
            'gagal'    => 'Silakan hubungi kasir untuk informasi',
          ];
          echo $subs[$d['status_pesanan']] ?? '';
        ?>
      </p>
    </div>

    <div class="card-body-wrap">

      <div class="info-row">
        <div class="info-col"><div class="lbl">No Pesanan</div><div class="val"><?= htmlspecialchars($d['no_pesanan']) ?></div></div>
        <div class="info-col"><div class="lbl">Nama</div><div class="val"><?= htmlspecialchars($d['nama_pelanggan']) ?></div></div>
        <div class="info-col"><div class="lbl">Meja</div><div class="val"><?= $d['nomor_meja'] ?></div></div>
      </div>

      <div id="blockBayar">
        <?php if($d['status_pembayaran'] == 'dibayar'): ?>
          <div class="status-alert alert-lunas"><h4>✅ Pembayaran Lunas</h4><p>Pembayaran telah dikonfirmasi oleh admin.</p></div>
        <?php elseif($d['status_pembayaran'] == 'gagal'): ?>
          <div class="status-alert alert-gagal"><h4>❌ Pembayaran Ditolak</h4><p>Bukti pembayaran tidak valid. Silakan hubungi kasir.</p></div>
        <?php else: ?>
          <div class="status-alert alert-pending"><h4>⏳ Menunggu Konfirmasi Pembayaran</h4><p>Admin sedang memverifikasi pembayaran Anda.</p></div>
        <?php endif; ?>
      </div>

      <div id="blockPesanan">
        <?php if($d['status_pesanan'] == 'menunggu'): ?>
          <div class="status-alert alert-menunggu"><h4>⏳ Menunggu Konfirmasi</h4><p>Pesanan Anda sedang antri untuk divalidasi.</p></div>
        <?php elseif($d['status_pesanan'] == 'diproses'): ?>
          <div class="status-alert alert-diproses"><h4>🍳 Sedang Dimasak</h4><p>Harap tunggu sekitar 10 menit ya!</p></div>
        <?php elseif($d['status_pesanan'] == 'diantar'): ?>
          <div class="status-alert alert-diantar"><h4>🛵 Sedang Diantar</h4><p>Pesanan dalam perjalanan ke meja Anda.</p></div>
        <?php elseif($d['status_pesanan'] == 'selesai'): ?>
          <div class="status-alert alert-selesai"><h4>✅ Pesanan Selesai</h4><p>Selamat menikmati makanannya!</p></div>
        <?php elseif($d['status_pesanan'] == 'gagal'): ?>
          <div class="status-alert alert-gagal"><h4>❌ Pesanan Tidak Diproses</h4><p>Mohon maaf. Silakan hubungi kasir.</p></div>
        <?php endif; ?>
      </div>

      <div id="timerBox" class="timer-box" style="display:none;">
        <div class="label">⏱️ Pesanan akan selesai dalam</div>
        <div class="time" id="timerCountdown">03:00</div>
        <div class="label">setelah waktu habis, status akan otomatis berubah</div>
      </div>

      <div class="refresh-bar">🔄 Memperbarui status otomatis setiap 3 detik</div>
    </div>
  </div>
</div>

<script>
const ORDER       = "<?= htmlspecialchars($d['no_pesanan'], ENT_QUOTES) ?>";
const MEJA        = "<?= htmlspecialchars($d['nomor_meja'], ENT_QUOTES) ?>";
const TIMER_KEY   = 'timer_diantar_' + ORDER;

let currentStatus = "<?= $d['status_pesanan'] ?>";
let currentBayar  = "<?= $d['status_pembayaran'] ?>";
let timerInterval = null;

/* ───── Timer ───── */
function startTimerUntil(endEpochMs) {
    stopTimer();
    const timerBox     = document.getElementById('timerBox');
    const timerDisplay = document.getElementById('timerCountdown');
    timerBox.style.display = 'block';

    function tick() {
        const remaining = Math.floor((endEpochMs - Date.now()) / 1000);
        if (remaining <= 0) {
            stopTimer();
            timerDisplay.textContent = '00:00';
            localStorage.removeItem(TIMER_KEY);
            // Panggil API → server set selesai, lalu tampilkan UI selesai + redirect
            fetch('cek_status_api.php?order=' + encodeURIComponent(ORDER) + '&t=' + Date.now())
                .then(r => r.json())
                .then(data => {
                    if (!data.error) updateUI(data);
                    // Paksa tampil selesai meski polling belum sempat
                    showSelesai();
                })
                .catch(() => showSelesai());
            return;
        }
        const m = Math.floor(remaining / 60);
        const s = remaining % 60;
        timerDisplay.textContent =
            m.toString().padStart(2,'0') + ':' + s.toString().padStart(2,'0');
    }
    tick();
    timerInterval = setInterval(tick, 1000);
}

function stopTimer() {
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
}

/* ───── Tampilkan UI Selesai + Countdown Redirect ───── */
function showSelesai() {
    if (currentStatus === 'selesai') return; // sudah ditampilkan
    currentStatus = 'selesai';

    document.getElementById('blockPesanan').innerHTML =
        '<div class="status-alert alert-selesai"><h4>✅ Pesanan Selesai</h4><p>Selamat menikmati makanannya!</p></div>';
    document.getElementById('cardTop').className     = 'card-top selesai';
    document.getElementById('statusIcon').innerHTML  = '✅';
    document.getElementById('headerTitle').innerHTML = 'Pesanan Selesai! 🎉';
    document.getElementById('headerSub').innerHTML   = 'Terima kasih telah makan di resto kami';
    document.getElementById('timerBox').style.display = 'none';
    stopTimer();
    localStorage.removeItem(TIMER_KEY);

    // Countdown 5 detik lalu redirect ke halaman menu
    let sisa = 5;
    const bar = document.querySelector('.refresh-bar');
    bar.innerHTML = `✅ Kembali ke menu dalam <strong>${sisa}</strong> detik...`;
    const cd = setInterval(() => {
        sisa--;
        if (sisa <= 0) {
            clearInterval(cd);
            window.location.href = 'index.php?meja=' + MEJA;
        } else {
            bar.innerHTML = `✅ Kembali ke menu dalam <strong>${sisa}</strong> detik...`;
        }
    }, 1000);
}

/**
 * Inisialisasi timer dengan prioritas:
 * 1. localStorage (agar tahan refresh)
 * 2. sisa detik dari server (PHP / API)
 */
function initTimer(sisaDetikServer) {
    const stored = localStorage.getItem(TIMER_KEY);
    let endEpochMs = null;

    if (stored) {
        const parsed = parseInt(stored, 10);
        // Masih valid (belum lewat 5 menit dari sekarang ke belakang)
        if (parsed > Date.now() - 300_000) {
            endEpochMs = parsed;
        }
    }

    if (!endEpochMs) {
        const sisa = (sisaDetikServer && sisaDetikServer > 0) ? sisaDetikServer : 180;
        endEpochMs = Date.now() + sisa * 1000;
        localStorage.setItem(TIMER_KEY, endEpochMs.toString());
    }

    startTimerUntil(endEpochMs);
}

/* ───── Update UI ───── */
function updateUI(data) {
    // Blok pembayaran
    if (data.status_pembayaran !== currentBayar) {
        let html = '';
        if (data.status_pembayaran === 'dibayar') {
            html = '<div class="status-alert alert-lunas"><h4>✅ Pembayaran Lunas</h4><p>Pembayaran telah dikonfirmasi oleh admin.</p></div>';
        } else if (data.status_pembayaran === 'gagal') {
            html = '<div class="status-alert alert-gagal"><h4>❌ Pembayaran Ditolak</h4><p>Bukti pembayaran tidak valid. Silakan hubungi kasir.</p></div>';
        } else {
            html = '<div class="status-alert alert-pending"><h4>⏳ Menunggu Konfirmasi Pembayaran</h4><p>Admin sedang memverifikasi pembayaran Anda.</p></div>';
        }
        document.getElementById('blockBayar').innerHTML = html;
        currentBayar = data.status_pembayaran;
    }

    // Blok pesanan
    if (data.status_pesanan !== currentStatus) {
        let pesanHtml = '', headerClass = '', headerIcon = '', headerTitle = '', headerSub = '';

        switch (data.status_pesanan) {
            case 'menunggu':
                pesanHtml   = '<div class="status-alert alert-menunggu"><h4>⏳ Menunggu Konfirmasi</h4><p>Pesanan Anda sedang antri untuk divalidasi.</p></div>';
                headerClass = 'menunggu'; headerIcon = '⏳';
                headerTitle = 'Menunggu Konfirmasi';
                headerSub   = 'Pesanan sedang menunggu konfirmasi admin';
                stopTimer(); localStorage.removeItem(TIMER_KEY);
                break;

            case 'diproses':
                pesanHtml   = '<div class="status-alert alert-diproses"><h4>🍳 Sedang Dimasak</h4><p>Harap tunggu sekitar 10 menit ya!</p></div>';
                headerClass = 'diproses'; headerIcon = '🍳';
                headerTitle = 'Sedang Dimasak';
                headerSub   = 'Harap tunggu sekitar 10 menit ya!';
                stopTimer(); localStorage.removeItem(TIMER_KEY);
                break;

            case 'diantar':
                pesanHtml   = '<div class="status-alert alert-diantar"><h4>🛵 Sedang Diantar</h4><p>Pesanan dalam perjalanan ke meja Anda.</p></div>';
                headerClass = 'diantar'; headerIcon = '🛵';
                headerTitle = 'Sedang Diantar';
                headerSub   = 'Pesanan dalam perjalanan ke meja Anda';
                initTimer(data.sisa_waktu);
                break;

            case 'selesai':
                showSelesai();
                return; // showSelesai sudah handle semua, keluar dari updateUI

            case 'gagal':
                pesanHtml   = '<div class="status-alert alert-gagal"><h4>❌ Pesanan Tidak Diproses</h4><p>Mohon maaf. Silakan hubungi kasir.</p></div>';
                headerClass = 'gagal'; headerIcon = '❌';
                headerTitle = 'Pesanan Ditolak';
                headerSub   = 'Silakan hubungi kasir untuk informasi';
                stopTimer(); localStorage.removeItem(TIMER_KEY);
                break;
        }

        document.getElementById('blockPesanan').innerHTML   = pesanHtml;
        document.getElementById('cardTop').className        = 'card-top ' + headerClass;
        document.getElementById('statusIcon').innerHTML     = headerIcon;
        document.getElementById('headerTitle').innerHTML    = headerTitle;
        document.getElementById('headerSub').innerHTML      = headerSub;
        currentStatus = data.status_pesanan;
    }
}

/* ───── Polling ───── */
function pollStatus() {
    fetch('cek_status_api.php?order=' + encodeURIComponent(ORDER) + '&t=' + Date.now())
        .then(r => r.json())
        .then(data => { if (!data.error) updateUI(data); })
        .catch(err => console.log('Poll error:', err));
}

/* ───── Boot ───── */
(function init() {
    <?php if ($d['status_pesanan'] === 'diantar'): ?>
    initTimer(<?= (int)$sisa ?>);
    <?php endif; ?>

    <?php if ($d['status_pesanan'] === 'selesai'): ?>
    showSelesai();
    <?php endif; ?>

    setInterval(pollStatus, 3000);
    pollStatus();
})();
</script>
</body>
</html>