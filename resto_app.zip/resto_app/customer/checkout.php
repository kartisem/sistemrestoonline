<?php
session_start();

include '../config/koneksi.php';

$meja = $_GET['meja'];

$total = 0;

if(!isset($_SESSION['cart'])){
    $_SESSION['cart'] = [];
}

foreach($_SESSION['cart'] as $id => $qty){

    $data = mysqli_query($conn,"
    SELECT * FROM menu
    WHERE id_menu='$id'
    ");

    $row = mysqli_fetch_array($data);

    $subtotal = $row['harga'] * $qty;

    $total += $subtotal;
}

if(isset($_POST['checkout'])){

    // CEK STOK SEBELUM CHECKOUT
    foreach($_SESSION['cart'] as $id => $qty){

        $cek = mysqli_query($conn,"
        SELECT * FROM menu
        WHERE id_menu='$id'
        ");

        $c = mysqli_fetch_array($cek);

        if($qty > $c['stok']){

            echo "
            <script>
            alert('Menu ".$c['nama_menu']." tinggal ".$c['stok'].". Mohon pilih menu yang lain');
            window.location='cart.php?meja=$meja';
            </script>
            ";

            exit;
        }
    }

    $nama       = $_POST['nama'];
    $pembayaran = $_POST['pembayaran'];
    $catatan    = $_POST['catatan'];

    $bukti = '';

    // VALIDASI QRIS WAJIB UPLOAD BUKTI
    if($pembayaran == 'QRIS'){

        if($_FILES['bukti_pembayaran']['name'] == ''){

            echo "
            <script>
            alert('Pembayaran QRIS wajib upload bukti pembayaran');
            window.location='checkout.php?meja=$meja';
            </script>
            ";

            exit;
        }
    }

    // STATUS PESANAN
    $status_pesanan = 'menunggu';

    // UPLOAD BUKTI — PATH ABSOLUT PAKAI __DIR__
    if(!empty($_FILES['bukti_pembayaran']['name'])){

        // __DIR__ = C:\xampp\htdocs\resto_app\customer
        // naik satu level ke resto_app, lalu masuk uploads/bukti/
        $folder = __DIR__ . '/../uploads/bukti/';

        // Buat folder jika belum ada
        if(!is_dir($folder)){
            mkdir($folder, 0755, true);
        }

        // Nama file bersih: tanpa spasi, tanpa karakter aneh
        $ekstensi = strtolower(pathinfo($_FILES['bukti_pembayaran']['name'], PATHINFO_EXTENSION));
        $bukti    = time() . '_' . uniqid() . '.' . $ekstensi;

        $upload_result = move_uploaded_file(
            $_FILES['bukti_pembayaran']['tmp_name'],
            $folder . $bukti
        );

        if(!$upload_result){
            $err = error_get_last();
            echo "
            <script>
            alert('Gagal upload bukti: ".addslashes($err['message'] ?? 'Coba lagi')."');
            window.location='checkout.php?meja=$meja';
            </script>
            ";
            exit;
        }
    }

    $no_pesanan = "ORD".rand(1000,9999);

    // INSERT KE TRANSAKSI
    $insert = mysqli_query($conn,"
    INSERT INTO transaksi(
    no_pesanan,
    nama_pelanggan,
    nomor_meja,
    catatan,
    metode_pembayaran,
    bukti_pembayaran,
    status_pembayaran,
    status_pesanan,
    total
    ) VALUES(
    '$no_pesanan',
    '$nama',
    '$meja',
    '$catatan',
    '$pembayaran',
    '$bukti',
    'pending',
    '$status_pesanan',
    '$total'
    )
    ");

    // CEK ERROR SQL
    if(!$insert){
        die("Query Error : ".mysqli_error($conn));
    }

    $id_transaksi = mysqli_insert_id($conn);

    foreach($_SESSION['cart'] as $id => $qty){

        $menu = mysqli_query($conn,"
        SELECT * FROM menu
        WHERE id_menu='$id'
        ");

        $m = mysqli_fetch_array($menu);

        $subtotal = $m['harga'] * $qty;

        mysqli_query($conn,"
        INSERT INTO detail_transaksi(
        id_transaksi,
        id_menu,
        qty,
        subtotal
        ) VALUES(
        '$id_transaksi',
        '$id',
        '$qty',
        '$subtotal'
        )
        ");

        $stok_baru = $m['stok'] - $qty;

        $status = 'aktif';

        if($stok_baru <= 0){
            $status = 'nonaktif';
        }

        mysqli_query($conn,"
        UPDATE menu SET
        stok='$stok_baru',
        status='$status'
        WHERE id_menu='$id'
        ");
    }

    unset($_SESSION['cart']);

    echo "
    <script>
    alert('Pesanan berhasil dikirim ke admin');
    window.location='success.php?order=$no_pesanan&meja=$meja&metode=$pembayaran';
    </script>
    ";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Checkout</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background: linear-gradient(135deg,#fff7f0,#ffe4d6);
    min-height:100vh;
    font-family:Segoe UI;
}

.checkout-card{
    border:none;
    border-radius:25px;
    overflow:hidden;
}

.header-box{
    background:linear-gradient(135deg,#ff6b35,#ff9f1c);
    color:white;
    padding:30px;
}

.table{
    border-radius:15px;
    overflow:hidden;
}

.table th{
    background:#ff6b35;
    color:white;
}

.btn-success{
    background:linear-gradient(135deg,#28a745,#20c997);
    border:none;
    border-radius:12px;
    padding:12px 25px;
    font-weight:bold;
}

.btn-secondary{
    border-radius:12px;
    padding:12px 25px;
}

.form-control{
    border-radius:12px;
    padding:12px;
}

.alert{
    border-radius:18px;
}

.total-box{
    background:#fff5ef;
    padding:15px;
    border-radius:15px;
}

</style>

</head>
<body>

<div class="container py-5">

<div class="card shadow-lg checkout-card">

<div class="header-box text-center">

<h2>🧾 Checkout Pesanan</h2>

<p class="mb-0">
Silakan cek kembali pesanan anda
</p>

</div>

<div class="card-body p-4">

<h5 class="mb-3 fw-bold">
Detail Pesanan
</h5>

<table class="table table-bordered align-middle">

<tr>
<th>Menu</th>
<th>Qty</th>
<th>Subtotal</th>
</tr>

<?php
foreach($_SESSION['cart'] as $id => $qty){

    $data = mysqli_query($conn,"
    SELECT * FROM menu
    WHERE id_menu='$id'
    ");

    $row = mysqli_fetch_array($data);

    $subtotal = $row['harga'] * $qty;
?>

<tr>

<td>
<img src="../uploads/menu/<?= $row['foto'] ?>"
width="70"
height="70"
style="object-fit:cover;border-radius:10px;"
class="me-2">

<?= $row['nama_menu'] ?>
</td>

<td><?= $qty ?></td>

<td>
Rp <?= number_format($subtotal) ?>
</td>

</tr>

<?php } ?>

</table>

<hr>

<form method="POST" enctype="multipart/form-data">

<div class="mb-3">

<label class="fw-bold mb-2">
Nama Pelanggan
</label>

<input type="text"
name="nama"
class="form-control"
placeholder="Masukkan nama anda"
required>

</div>

<div class="mb-4">

<label class="fw-bold mb-2">
Catatan Pesanan
</label>

<textarea
name="catatan"
class="form-control"
rows="3"
placeholder="Contoh: tidak pedas, sambal dipisah, tanpa es, dll"></textarea>

</div>

<div class="mb-3">

<label class="fw-bold mb-2">
Tipe Pembayaran
</label>

<select name="pembayaran"
class="form-control"
required>

<option value="">-- Pilih Pembayaran --</option>
<option value="QRIS">QRIS</option>
<option value="Tunai">Tunai</option>

</select>

</div>

<div class="total-box mb-4">

<h4 class="mb-0 text-success">
Total :
Rp <?= number_format($total) ?>
</h4>

</div>

<div id="qris-box"
style="display:none;">

<div class="alert alert-success">

<h5>📱 Pembayaran QRIS</h5>

<p>
Silakan scan QRIS berikut untuk melakukan pembayaran.
</p>

<?php
$bank = mysqli_query($conn,"
SELECT * FROM bank
ORDER BY id_bank DESC
LIMIT 1
");

$b = mysqli_fetch_array($bank);
?>

<?php if($b){ ?>

<div class="text-center">

<img src="../uploads/bank/<?= $b['qris'] ?>"
width="250"
class="img-fluid rounded shadow">

</div>

<p class="mt-3 text-center">
Atas Nama :
<b><?= $b['nama_pemilik'] ?></b>
</p>

<hr>

<label class="form-label fw-bold">
Upload Bukti Pembayaran
</label>

<input type="file"
name="bukti_pembayaran"
class="form-control"
accept="image/*">

<small class="text-muted">
Upload screenshot bukti transfer QRIS (JPG, PNG, JPEG)
</small>

<?php } else { ?>

<div class="alert alert-danger">
Data bank belum tersedia
</div>

<?php } ?>

</div>

</div>

<div id="tunai-box"
style="display:none;">

<div class="alert alert-warning">

<h5>💵 Pembayaran Tunai</h5>

<p>
Silakan pergi ke kasir untuk melakukan pembayaran dan menunggu validasi admin.
</p>

</div>

</div>

<div class="d-flex gap-2">

<button name="checkout"
class="btn btn-success">

Pesan Sekarang

</button>

<a href="cart.php?meja=<?= $meja ?>"
class="btn btn-secondary">

Kembali

</a>

</div>

</form>

</div>

</div>

</div>

<script>

const pembayaran = document.querySelector('[name="pembayaran"]');

const qrisBox = document.getElementById('qris-box');

const tunaiBox = document.getElementById('tunai-box');

pembayaran.addEventListener('change', function(){

    if(this.value == 'QRIS'){

        qrisBox.style.display = 'block';
        tunaiBox.style.display = 'none';

    }
    else if(this.value == 'Tunai'){

        qrisBox.style.display = 'none';
        tunaiBox.style.display = 'block';

    }
    else{

        qrisBox.style.display = 'none';
        tunaiBox.style.display = 'none';

    }

});

</script>

</body>
</html>