<?php
include '../config/koneksi.php';

if(!isset($_GET['id']) || !isset($_GET['status'])){
    die("Parameter tidak lengkap");
}

$id     = mysqli_real_escape_string($conn, $_GET['id']);
$status = mysqli_real_escape_string($conn, $_GET['status']);

// Update status pesanan
mysqli_query($conn,
    "UPDATE transaksi SET status_pesanan='$status' WHERE id_transaksi='$id'"
);

// Catat waktu_diantar saat status berubah ke diantar
if($status == 'diantar'){
    mysqli_query($conn,
        "UPDATE transaksi SET waktu_diantar = NOW() WHERE id_transaksi='$id'"
    );
}

// Catat waktu_selesai saat status berubah ke selesai
if($status == 'selesai'){
    mysqli_query($conn,
        "UPDATE transaksi SET waktu_selesai = NOW() WHERE id_transaksi='$id'"
    );
}

header("Location: transaksi.php");
exit;
?>