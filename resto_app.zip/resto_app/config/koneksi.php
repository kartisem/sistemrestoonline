<?php

$conn = mysqli_connect("localhost", "root", "", "resto_qr");

if (!$conn) {
    die("Koneksi gagal");
}

?>